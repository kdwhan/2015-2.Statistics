#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<assert.h>
#include<math.h>

#define PATH_FILE "b.txt"

#ifndef DATATYPE
#define DATATYPE

#define SCANFORMAT "%f"
#define PRNFORMAT "%7.3f"

typedef float EType;
#endif

#ifndef MULTIVRAIATE
#define MULTIVRAIATE
typedef struct
{
	int rows;
	int cols;
	char ids[50];
	int length;
	EType **elem;
	float slope;
	float inter;
}MultiVariateSet;
#endif

static MultiVariateSet *CreateMultiVariateSet(const char *filename);
static void DestroyMultiVariateSet(MultiVariateSet *variateSet);
static void PrintMultiVariateSet(MultiVariateSet *variateSet);

static float ComputeCovariance(MultiVariateSet *variateSet);
static float ComputeCorrelation(MultiVariateSet *variateSet);
static float cal_slope(MultiVariateSet *variateSet);

//������, ���� ������ ���Ϳ� ���� �װ� n ���� ������
int main(int argc, char *argvp[])
{
	MultiVariateSet *setVariate = NULL;
	setVariate = CreateMultiVariateSet(PATH_FILE);
	PrintMultiVariateSet(setVariate);
	printf("\n");

	printf("Covariance = %6.3f\n", ComputeCovariance(setVariate));
	printf("Correlation = %6.3f\n", ComputeCorrelation(setVariate));
	printf("\n");

	setVariate->slope *= ComputeCorrelation(setVariate);

	printf("slope = %6.3f\n",setVariate -> slope);
	

	DestroyMultiVariateSet(setVariate);
	return 0;
}
static float cal_slope(MultiVariateSet *variateSet)
{
	int i;
	float SDx, SDy;
	for (i = 0; i < variateSet->cols; i++)
	{
		SDx += (variateSet->elem[0][i] - variateSet->meanX) * (variateSet->elem[0][i] - variateSet->meanX);
		SDy += (variateSet->elem[1][i] - variateSet->meanY) * (variateSet->elem[1][i] - variateSet->meanY);
	}
	SDx = sqrtf(SDx);
	SDy = sqrtf(SDy);

}

static MultiVariateSet *CreateMultiVariateSet(const char *filename)
{
	FILE *infile;
	MultiVariateSet *out; // return
	int i,j;

	infile = fopen(filename, "r");
	
	if (!infile)
		abort();
	out = (MultiVariateSet*)malloc(sizeof(MultiVariateSet));
	if (!out)
		abort();

	fscanf(infile, "%d %d %d", &out->rows, &out->cols, &out->length);
	
	fgets(out->ids, 49, infile);
	fgets(out->ids, 49, infile);

	out->elem = (EType**)malloc(sizeof(EType*) * out->rows);
	for (i = 0; i < out->rows; i++)
	{
		out->elem[i] = (EType*)malloc(sizeof(EType) * out->cols);
		for (j = 0; j < out->cols; j++)
		{
			fscanf_s(infile, "%f", &out->elem[i][j]);
		}
	}

	return out;
}
static void DestroyMultiVariateSet(MultiVariateSet *variateSet)
{
	
}
static void PrintMultiVariateSet(MultiVariateSet *variateSet)
{
	int i, j;

	printf("%s",variateSet->ids);
	printf("\n---------------------------------------------------\n");
	for (i = 0; i < variateSet->cols; i++)
	{
		for (j = 0; j < variateSet->rows; j++)
		{
			printf(PRNFORMAT, variateSet->elem[j][i]);
		}
		printf("\n");
	}
}

static float ComputeCovariance(MultiVariateSet *variateSet)
{
	int i, j;
	float cov = 0;
	float out=1;
	float *m;
	m = (float*)malloc(sizeof(float)*variateSet->rows);
	

	for (i = 0; i < variateSet->rows; i++)
	{
		m[i] = 0;
		for (j = 0; j < variateSet->cols; j++)
		{
			m[i] += variateSet->elem[i][j];
		}
		m[i] = m[i] / variateSet->cols;
	}

	for (j = 0; j < variateSet->cols; j++)
	{
		for (i = 0; i < variateSet->rows; i++)
		{
			out *= (variateSet->elem[i][j] - m[i]);
		}
		cov += out;
		out = 1;
	}



	cov /= variateSet->cols;

	return cov;
}
static float ComputeCorrelation(MultiVariateSet *variateSet)
{
	int i, j;
	float cov = 0;
	float out = 1;
	float cor1=0, cor2=1;
	float *m;
	m = (float*)malloc(sizeof(float)*variateSet->rows);


	for (i = 0; i < variateSet->rows; i++)
	{
		m[i] = 0;
		for (j = 0; j < variateSet->cols; j++)
		{
			m[i] += variateSet->elem[i][j];
		}
		m[i] = m[i] / variateSet->cols;

		for (j = 0; j < variateSet->cols; j++)
		{
			cor1 += ((variateSet->elem[i][j] - m[i]) * (variateSet->elem[i][j] - m[i]));
		}

		cor1 = sqrt(cor1);

		cor2 *= cor1;
		
		if (i = 0)
		{
			variateSet->slope = 1 / cor1;
		}
		else
		{
			variateSet->slope *= cor1;
		}
		cor1 = 0;
	}

	for (j = 0; j < variateSet->cols; j++)
	{
		for (i = 0; i < variateSet->rows; i++)
		{
			out *= (variateSet->elem[i][j] - m[i]);
		}
		cov += out;
		out = 1;
	}

	out = cov / cor2;



	return out;
}